<?php

error_reporting(E_ALL | E_DEPRECATED | E_STRICT);
ini_set('display_errors', 'On');

date_default_timezone_set('UTC');
